# sample songs
## sample 1
- sample-1_electric-guitar_8000.wav: 単チャネルエレキギター音 (サンプリング周波数 8kHz)

## sample 2
多チャネル音源分離用クラシック音楽
- sample-2_piano_16000.wav: 単チャネルピアノ音 (サンプリング周波数 16kHz)
- sample-2_violin_16000.wav: 単チャネルヴァイオリン音 (サンプリング周波数 16kHz)
- sample-2_mixture_16000.wav: 多チャネル混合音 (サンプリング周波数 16kHz, 残響時間 0.160s)

## sample 3
多チャネル音源分離用J pop
- sample-3_piano_16000.wav: 単チャネルピアノ音 (サンプリング周波数 16kHz)
- sample-3_bass_16000.wav: 単チャネルベース音 (サンプリング周波数 16kHz)
- sample-3_mixture_16000.wav: 多チャネル混合音 (サンプリング周波数 16kHz, 残響時間 0.160s)